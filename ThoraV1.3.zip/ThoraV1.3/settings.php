<?php 

$user_id = "xxx";

$user_agent = "xxx";

?>