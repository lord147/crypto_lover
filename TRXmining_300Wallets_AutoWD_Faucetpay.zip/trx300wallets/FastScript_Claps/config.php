<?php


// Enter Your Token

$token = "NGJlMTE4MmQtNTZjYy00NGJlLWEzZGMtOWNjNzRlYjVkYTFl";


// Enter Your User Id

$user = "63695241";


// Enter Your Uuid

$uid = "8f2f8b97e037c416";





?>
