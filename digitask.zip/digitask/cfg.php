<?
//PERHATIKAN CARA ADMIN MENGISI DATA
$url = "xxxxx";
$cookie = "xxxxx";
$user = "xxxxx";