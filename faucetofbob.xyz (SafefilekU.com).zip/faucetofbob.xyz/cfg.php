<?php

# Your User-Agent 👇

$uag = "xxxxxxxxxx";


# Your Cookie 👇

$cookie = "xxxxxxxxxx";








?>
